import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATA_RAW_DIR = os.path.join(BASE_DIR, "data", "raw")
DATA_SOURCE_DB = os.path.join(BASE_DIR, "data", "source_db", "store.db")
DATA_WAREHOUSE_DB = os.path.join(BASE_DIR, "data", "warehouse", "warehouse.db")

OUTPUT_DIR = os.path.join(BASE_DIR, "output")
REJECTS_PATH = os.path.join(OUTPUT_DIR, "rejects.csv")
VALIDATION_PATH = os.path.join(OUTPUT_DIR, "validation.json")

LOGS_DIR = os.path.join(BASE_DIR, "logs")
LOG_FILE = os.path.join(LOGS_DIR, "etl.log")
