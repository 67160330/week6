import os
import sqlite3
from src.config import DATA_WAREHOUSE_DB

def load_data(transformed):
    os.makedirs(os.path.dirname(DATA_WAREHOUSE_DB), exist_ok=True)
    conn = sqlite3.connect(DATA_WAREHOUSE_DB)
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dim_customer (
        customer_id TEXT PRIMARY KEY,
        name TEXT,
        province TEXT,
        email TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dim_product (
        product_id TEXT PRIMARY KEY,
        product_name TEXT,
        category TEXT,
        price REAL
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS fact_sales (
        order_id TEXT PRIMARY KEY,
        customer_id TEXT,
        product_id TEXT,
        order_date TEXT,
        qty INTEGER,
        unit_price REAL,
        discount_pct REAL,
        sales_amount REAL,
        FOREIGN KEY (customer_id) REFERENCES dim_customer(customer_id),
        FOREIGN KEY (product_id) REFERENCES dim_product(product_id)
    )
    """)
    conn.commit()

    for df, table_name, pk in [
        (transformed["dim_customer"], "dim_customer", "customer_id"),
        (transformed["dim_product"], "dim_product", "product_id"),
        (transformed["fact_sales"], "fact_sales", "order_id")
    ]:
        temp_table = f"temp_{table_name}"
        df.to_sql(temp_table, conn, if_exists="replace", index=False)
        
        cols = ", ".join(df.columns)
        cursor.execute(f"INSERT OR REPLACE INTO {table_name} ({cols}) SELECT {cols} FROM {temp_table}")
        cursor.execute(f"DROP TABLE {temp_table}")

    conn.commit()
    conn.close()
