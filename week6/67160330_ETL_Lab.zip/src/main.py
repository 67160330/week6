import logging
import os
from src.config import LOG_FILE
from src.extract import extract_data
from src.transform import transform_data
from src.load import load_data
from src.validate import validate_etl

def setup_logging():
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    logging.basicConfig(
        filename=LOG_FILE,
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        force=True
    )

def main():
    setup_logging()
    logging.info("ETL Pipeline Started")

    print("1. Extracting data...")
    raw = extract_data()
    logging.info("Extract completed")

    print("2. Transforming data...")
    transformed = transform_data(raw)
    logging.info("Transform completed")

    print("3. Loading data into Warehouse...")
    load_data(transformed)
    logging.info("Load completed")

    print("4. Validating ETL Pipeline...")
    res = validate_etl(transformed)
    logging.info(f"Validation completed. Status: {res['status']}")

    print("\n--- Summary ---")
    print(f"Validation Status : {res['status']}")
    print(f"Valid Source Rows : {res['source_valid_rows']}")
    print(f"Warehouse Rows   : {res['warehouse_rows']}")
    print(f"Total Sales      : {res['source_total_sales']}")

if __name__ == "__main__":
    main()
