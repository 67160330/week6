import os
import pandas as pd
import numpy as np
from src.config import REJECTS_PATH, OUTPUT_DIR

def transform_data(raw):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    customers = raw["customers"].copy()
    orders = raw["orders"].copy()
    products = raw["products"].copy()

    # --- 1. Clean Customers ---
    if "customer_id" in customers.columns:
        customers = customers.drop_duplicates(subset=["customer_id"])
    
    if "province" in customers.columns:
        customers["province"] = customers["province"].astype(str).str.strip().str.title()
        customers["province"] = customers["province"].replace({"Nan": np.nan, "None": np.nan, "": np.nan})
        customers["province"] = customers["province"].fillna("Unknown")

    if "name" in customers.columns:
        customers["name"] = customers["name"].fillna("Unknown")
    if "email" in customers.columns:
        customers["email"] = customers["email"].fillna("Unknown")

    # --- 2. Clean Products ---
    if "category.name" in products.columns:
        if "category" in products.columns:
            products["category"] = products["category.name"].fillna(products["category"])
            products = products.drop(columns=["category.name"])
        else:
            products = products.rename(columns={"category.name": "category"})

    if "pricing.price" in products.columns:
        if "price" in products.columns:
            products["price"] = products["pricing.price"].fillna(products["price"])
            products = products.drop(columns=["pricing.price"])
        else:
            products = products.rename(columns={"pricing.price": "price"})

    rename_map = {}
    for col in products.columns:
        if col in ["id", "prod_id"]:
            rename_map[col] = "product_id"
        elif col in ["title", "name", "product_title"]:
            rename_map[col] = "product_name"
    products = products.rename(columns=rename_map)

    if "product_id" in products.columns:
        products = products.drop_duplicates(subset=["product_id"])

    if "price" in products.columns:
        products["price"] = pd.to_numeric(products["price"], errors="coerce").fillna(0.0)

    if "category" in products.columns:
        products["category"] = products["category"].fillna("Unknown")
    else:
        products["category"] = "Unknown"

    # --- 3. Clean Orders & Track Rejects ---
    rejects_list = []

    if "order_id" in orders.columns:
        duplicates = orders[orders.duplicated(subset=["order_id"], keep="first")]
        if not duplicates.empty:
            dup_df = duplicates.copy()
            dup_df["reject_reason"] = "Duplicate order_id"
            rejects_list.append(dup_df)
        orders = orders.drop_duplicates(subset=["order_id"], keep="first")

    date_col = "order_date" if "order_date" in orders.columns else "date"
    orders["order_date_parsed"] = pd.to_datetime(orders[date_col], errors="coerce", format="mixed")

    if "status" in orders.columns:
        orders["status"] = orders["status"].astype(str).str.strip().str.lower()

    orders["qty"] = pd.to_numeric(orders["qty"], errors="coerce")
    orders["unit_price"] = pd.to_numeric(orders["unit_price"], errors="coerce")
    orders["discount_pct"] = pd.to_numeric(orders["discount_pct"], errors="coerce").fillna(0)

    invalid_date = orders["order_date_parsed"].isna()
    invalid_qty = orders["qty"].isna() | (orders["qty"] <= 0)
    invalid_price = orders["unit_price"].isna() | (orders["unit_price"] < 0)
    invalid_discount = (orders["discount_pct"] < 0) | (orders["discount_pct"] > 100)

    valid_cust_ids = set(customers["customer_id"].dropna().unique())
    valid_prod_ids = set(products["product_id"].dropna().unique())

    missing_cust = ~orders["customer_id"].isin(valid_cust_ids)
    missing_prod = ~orders["product_id"].isin(valid_prod_ids)

    r_date = orders[invalid_date].copy(); r_date["reject_reason"] = "Invalid date format"
    r_qty = orders[~invalid_date & invalid_qty].copy(); r_qty["reject_reason"] = "qty <= 0"
    r_price = orders[~invalid_date & ~invalid_qty & invalid_price].copy(); r_price["reject_reason"] = "unit_price < 0"
    r_disc = orders[~invalid_date & ~invalid_qty & ~invalid_price & invalid_discount].copy(); r_disc["reject_reason"] = "discount_pct < 0 or > 100"
    r_cust = orders[~invalid_date & ~invalid_qty & ~invalid_price & ~invalid_discount & missing_cust].copy(); r_cust["reject_reason"] = "customer_id not in master"
    r_prod = orders[~invalid_date & ~invalid_qty & ~invalid_price & ~invalid_discount & ~missing_cust & missing_prod].copy(); r_prod["reject_reason"] = "product_id not in master"

    reject_dfs = [r_date, r_qty, r_price, r_disc, r_cust, r_prod] + rejects_list
    all_rejects = pd.concat([df for df in reject_dfs if not df.empty], ignore_index=True)
    all_rejects.to_csv(REJECTS_PATH, index=False)

    valid_mask = (~invalid_date & ~invalid_qty & ~invalid_price & ~invalid_discount & ~missing_cust & ~missing_prod)
    valid_orders = orders[valid_mask].copy()

    valid_orders = valid_orders[valid_orders["status"].isin(["paid", "completed"])].copy()
    valid_orders["order_date"] = valid_orders["order_date_parsed"].dt.strftime("%Y-%m-%d")

    merged = valid_orders.merge(customers, on="customer_id", how="inner")
    merged = merged.merge(products, on="product_id", how="inner")

    merged["gross_amount"] = merged["qty"] * merged["unit_price"]
    merged["discount_amount"] = merged["gross_amount"] * (merged["discount_pct"] / 100.0)
    merged["sales_amount"] = merged["gross_amount"] - merged["discount_amount"]

    transformed = {
        "dim_customer": customers[["customer_id", "name", "province", "email"]],
        "dim_product": products[["product_id", "product_name", "category", "price"]],
        "fact_sales": merged[["order_id", "customer_id", "product_id", "order_date", "qty", "unit_price", "discount_pct", "sales_amount"]],
        "transformed_df": merged
    }

    return transformed
