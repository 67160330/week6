import os
import sqlite3
import json
import pandas as pd
from src.config import DATA_RAW_DIR, DATA_SOURCE_DB

def get_file_path(filename, default_path):
    if os.path.exists(default_path):
        return default_path
    for root, dirs, files in os.walk("."):
        if filename in files:
            return os.path.join(root, filename)
    return default_path

def extract_data():
    cust_path = get_file_path("customers.csv", os.path.join(DATA_RAW_DIR, "customers.csv"))
    orders_path = get_file_path("orders.csv", os.path.join(DATA_RAW_DIR, "orders.csv"))
    prod_path = get_file_path("products.json", os.path.join(DATA_RAW_DIR, "products.json"))
    db_path = get_file_path("store.db", DATA_SOURCE_DB)

    customers = pd.read_csv(cust_path)
    orders = pd.read_csv(orders_path)

    with open(prod_path, "r", encoding="utf-8") as f:
        products_raw = json.load(f)
    products = pd.json_normalize(products_raw)

    conn = sqlite3.connect(db_path)
    stores = pd.read_sql_query("SELECT * FROM stores", conn)
    conn.close()

    raw = {
        "customers": customers,
        "orders": orders,
        "products": products,
        "stores": stores,
    }
    return raw
