import json
import os
import sqlite3
import pandas as pd
from src.config import DATA_WAREHOUSE_DB, VALIDATION_PATH

def validate_etl(transformed):
    fact_sales = transformed["fact_sales"]
    source_valid_rows = len(fact_sales)
    source_total_sales = round(float(fact_sales["sales_amount"].sum()), 2)

    conn = sqlite3.connect(DATA_WAREHOUSE_DB)
    df_wh = pd.read_sql_query("SELECT * FROM fact_sales", conn)
    conn.close()

    warehouse_rows = len(df_wh)
    duplicate_order_ids = int(df_wh["order_id"].duplicated().sum())
    warehouse_total_sales = round(float(df_wh["sales_amount"].sum()), 2)

    status = "PASS" if (
        source_valid_rows == warehouse_rows and
        duplicate_order_ids == 0 and
        abs(source_total_sales - warehouse_total_sales) < 0.01
    ) else "FAIL"

    validation_result = {
        "source_valid_rows": source_valid_rows,
        "warehouse_rows": warehouse_rows,
        "duplicate_order_ids": duplicate_order_ids,
        "source_total_sales": source_total_sales,
        "warehouse_total_sales": warehouse_total_sales,
        "status": status
    }

    os.makedirs(os.path.dirname(VALIDATION_PATH), exist_ok=True)
    with open(VALIDATION_PATH, "w", encoding="utf-8") as f:
        json.dump(validation_result, f, indent=4)

    return validation_result
